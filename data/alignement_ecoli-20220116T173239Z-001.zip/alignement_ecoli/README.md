Source : https://doi.org/10.1186/s12864-018-5243-3
Alignement de 251 souches de E.coli O157:H7 qui contient 8 outbreak
