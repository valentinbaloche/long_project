Alignement de 42 souches de variant monophasique (prédit comme variant monophasique par SeqSero2).
Aucunes informations sur ces souches, et si elles sont reliés entre-elles ou non.
